#pragma once

void testPlayers();