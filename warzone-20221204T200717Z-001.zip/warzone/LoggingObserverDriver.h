#pragma once

void testLoggingObserver();
