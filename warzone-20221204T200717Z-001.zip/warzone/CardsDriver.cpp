#include "Card.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm> 
using namespace std;

void testCards(){
    //cout<<"\nPart 4: Cards Deck/Hand"<<endl;
    //cout<<"----------------------------------------------------------------------"<<endl;
    //srand(time(0));
    //cout<<"Creating Deck object \n---------------------------------"<<endl;
    //Deck *d = new Deck();
    //cout<< *d;
    //cout<<"\nCreating Hand object \n---------------------------------" <<endl;
    ////cout<<d.draw()->get_cardType()<<"  "<< rand()%14 <<endl;
    //Hand *h = new Hand();
    ////fill cards into hand by repeatedly calling draw method
    //cout<<"\nrepeatedly calling draw method and put 6 random cards in player's hand"<<endl;
    //for(int i = 0;i<6;i++){
    //     h->add_CardinHand(d->draw());
    //}
    ////output cards in hand 
    //cout<<*h;
    //cout<<"\nThe cards remaining in the deck after draw cards:" <<endl;
    ////output cards in deck
    //cout<<*d;
    ////call the play method of all cards in hand
    //for (int i = 0;i< h->numOfHandCards();i++){
    //h->get_VectorOfHand().at(i)->play(d, h);
    //}
    ////removing all cards in hand after paly
    //h->remove_CardinHand();
    //cout<<"\nAfter playing all cards on hand:\n\n"<<*d;
    //cout<<*h;
    //delete d;
    //delete h;
    //cout << "Cards deck/hand demo end." << endl << endl;
};


