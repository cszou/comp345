#pragma once

void testLoadMaps();