#pragma once
#include "Player.h"

void testStartupPhase();
void testMainGameLoop(Player* p1, Player* p2);
