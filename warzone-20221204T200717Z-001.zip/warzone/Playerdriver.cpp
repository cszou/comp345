#include "Player.h"
#include "Orders.h"
#include "Card.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm> 
#include <sstream>
void testPlayers() 
{
   /* cout<<"\nPart 2: Player"<<endl;
    cout<<"----------------------------------------------------------------------"<<endl;
    vector<Territory*> t;
	t.push_back(new Territory("NB"));
	t.push_back(new Territory("NS"));
	Hand* h = new Hand();
    h->add_CardinHand(new Card("bomb"));
    h->add_CardinHand(new Card("blockade"));
    string name = "xuz";
	cout << "Create a new player \n-----------------------------------------" << std::endl;
    Player* p1 = new Player(t, h, name);
    cout << *p1 << endl;
    cout << "Territories to attack:" << endl;
    for (auto t : p1->toAttack())
        cout << *t << endl;
    cout << "Territories to defend:" << endl;
    for (auto t : p1->toDefend())
        cout << *t << endl;
    cout << "Player issues an order:" << endl;
    p1->issueOrder();
    cout << "Player now has " << p1->getlist().size() << " orders." << endl;
    delete p1;
    p1 = nullptr;
    cout << "Player demo end." << endl << endl;*/
}
