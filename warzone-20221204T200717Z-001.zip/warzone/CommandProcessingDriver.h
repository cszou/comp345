#pragma once

void testCommandProcessor();