#include "Player.h"
#include "PlayerStrategies.h"

void testPlayerStrategies();